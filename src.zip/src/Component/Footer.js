import React from "react"
function Footer(){
    return(
    <h4 className="footer">Try to complete all task</h4>
    )
}
export default Footer
