import React from "react"
function Navbar(){
    return(
        <h1 className="navy">To Do List</h1>
    )
}
export default Navbar
