import React from "react"
import Navbar from "./Navbar.js"
import Content from "./Content.js"
import Footer from "./Footer.js"

function App(){
    return (
        <div>
          <Navbar></Navbar>
          <Content></Content>
          <Footer></Footer>      
        </div>
    )
}

export default App
