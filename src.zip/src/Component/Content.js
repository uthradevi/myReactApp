import React from "react"

function Content(){
    return (
    <div>
    <table className="listTable">
     <tbody>
       <tr><td><input className="check" type="checkbox" name="sleep"/></td><td>have to sleep</td></tr>
        <tr><td><input className="check" type="checkbox"  name="eat"/></td><td> should eat at the correct time </td></tr>
         <tr><td> <input className="check" type="checkbox"  name="work"/></td><td>should not skip your work </td></tr>
       </tbody>
    </table>
    </div>
    )
}
export default Content
